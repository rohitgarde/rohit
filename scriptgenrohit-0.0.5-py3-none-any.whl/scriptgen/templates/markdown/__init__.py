#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from ._markdown import \
    markdown_autogen, \
    markdown_code_block, \
    markdown_comment, \
    markdown_inline
