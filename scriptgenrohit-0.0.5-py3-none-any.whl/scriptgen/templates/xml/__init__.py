#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from ._xml import \
    XmlElementBuilder, \
    xml_attributes, \
    xml_autogen, \
    xml_comment, \
    xml_declaration
